import kotlin.math.pow
fun main() {
    print("введите первое число: ")
    var num1=readLine()!!.toDouble()
    print("введите второе число: ")
    var num2=readLine()!!.toDouble()
    when{
        num1>num2->num1=num1+1
        num2>num1->num2=num2+1
        else -> num1=num1.pow(3)
    }
    println("первое число:$num1 второе число $num2")


        }





