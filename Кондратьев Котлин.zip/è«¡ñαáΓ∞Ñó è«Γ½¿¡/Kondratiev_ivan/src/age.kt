fun main(){
    println("введите возраст какой категории вы хотите: ")
    var num=readln()!!.toDouble()
    when{
        (num>=0)&&(num<=2)->
            println("младенец")
        (num>=3)&&(num<=13)->
            println("ребёнок")
        (num>=14)&&(num<=17)->
            println("подросток")
        (num>=18)&&(num<=30)->
            println("средний возраст")
        (num>=31)&&(num<=64)->
            println("взрослый")
        (num>=65)->
            println("пенсионер")
        else->println("так нельзя")
    }
}