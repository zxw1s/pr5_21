fun main(){
    print ("введите ваше число: ")
    val num=readLine()!!.toInt()
    var otv=0
    when {
        (num>7)->
            otv= (1/(num*num-7))
    }
    when {
        (num<=7)->
            otv=(-3*num+9)
    }
    println("ответ: $otv")
}